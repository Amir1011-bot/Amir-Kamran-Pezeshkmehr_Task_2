/* Welcome to WebprogDIG! I'd like to get to know you a bit and learn a bit about your experiences.

   Please fill in your answers below. Make sure not to change the variable names or remove the `export`.
   Since the values are all strings, they will need to be quoted. You can use backquotes (`) if you want to easily include a newline. */

/*** About You ***/

/* Your matriculation number */
export const matriculationNumber = "11927901";

/* Your name? */
export const name = "Amir Kamran Pezeshkmehr";

/* What is your nationality? */
export const nationality = "Iranian";

/* How old are you? */
export const age = "39";

/* What did you do before studying? What school did you go to?  */
export const priorEducation = "Before I entered the University of Salzburg, I received my bachelor's degree from the European University of Armenia. I am currently pursuing my master's degree at the University of Salzburg and i am almost in my final semester.";

/***
 * 
 *  About Your Experiences 
 * 
 * ***/

/* What topic/part of the class are you most interested in? */
export const topicInterest = "I am most interested in learning about web development and how to create interactive and dynamic websites. I am also interested in learning about the different technologies and frameworks used in web development, such as HTML, CSS, JavaScript, and React.";

/* Do you have any prior experience with web development?
   If so, please describe it. If not, just remove the TODO. */
export const priorWebdev = "I have some prior experience with web development. I have created a few simple websites using HTML, CSS, and JavaScript. I have also worked with some web development frameworks such as React and Angular. However, I am still a beginner in web development and I am eager to learn more about it.";

/* What's your favorite computer science experience?
   E.g. a class you've taken or a project you worked on. */
export const favCSExp = "Advanced Databases was one of the most popular courses I have ever taken at the University of Salzburg.";

/* Anything else you want us to know? You can leave this blank by removing the TODO. */
export const anythingElse = "No, thank you to all the professors.";
